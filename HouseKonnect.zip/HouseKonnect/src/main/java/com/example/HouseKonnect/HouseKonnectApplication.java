package com.example.HouseKonnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HouseKonnectApplication {
	public static void main(String[] args) {
		SpringApplication.run(HouseKonnectApplication.class, args);
	}
}
