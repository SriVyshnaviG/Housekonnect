package com.example.HouseKonnect.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.HouseKonnect.model.User;
import com.example.HouseKonnect.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    UserService uService;

    @RequestMapping(value="/users", method=RequestMethod.POST)
    public User createUser(@RequestBody User user) {
        return uService.createUser(user);
    }

    @RequestMapping(value="/users", method=RequestMethod.GET)
    public List<User> readUsers() {
        try {
            return uService.getUsers();
        } catch (Exception e) {
            System.out.println("error");
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(value="/users/{userId}", method=RequestMethod.GET)
    public User getUser(@PathVariable Long userId) {
        return uService.getuserById(userId);
    }

    @RequestMapping(value="/users/{userId}", method=RequestMethod.PUT)
    public User readUsers(@PathVariable(value = "userId") Long id, @RequestBody User userDetails) {
        return uService.updateUser(id, userDetails);
    }

    @RequestMapping(value="/users/delete/{userId}", method=RequestMethod.DELETE)
    public void deleteUsers(@PathVariable(value = "userId") Long userId) {
        uService.deleteUser(userId);
    }
}
