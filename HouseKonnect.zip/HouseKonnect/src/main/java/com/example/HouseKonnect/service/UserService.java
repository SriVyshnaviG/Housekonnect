package com.example.HouseKonnect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HouseKonnect.model.User;
import com.example.HouseKonnect.repository.UserRepository;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    UserRepository uRepository;

    // CREATE
    public User createUser(User user) {
        return uRepository.save(user);
    }

    // READ All User
    public List<User> getUsers() {
        return uRepository.findAll();
    }

   // Read user by id
   public User getuserById(Long id) {
       Optional<User> user = uRepository.findById(id);
       if(user.isPresent()) {
           return user.get();
       }
       throw new RuntimeException("User is not found for the id " + id);
   }

    // DELETE
    public void deleteUser(Long userId) {
        uRepository.deleteById(userId);
    }

    // UPDATE
    public User updateUser(Long userId, User userDetails) {
        User userData = uRepository.findById(userId).get();
        userData.setName(userDetails.getName());
        userData.setPhoneNo(userDetails.getPhoneNo());
        userData.setEmail(userDetails.getEmail());
        userData.setAddress(userDetails.getAddress());
        userData.setUsername(userDetails.getUsername());
        userData.setType(userDetails.getType());
        return uRepository.save(userData);
    }
}
