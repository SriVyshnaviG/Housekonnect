package com.example.HouseKonnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouseKonnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
